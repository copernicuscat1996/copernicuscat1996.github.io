THE SON THEY BLAMED — WEBSITE

This is a ready-to-publish static website for:
Copernicus Cigar A. Tungbaban
The Son They Blamed

Files:
- index.html — website page
- style.css — design
- cover.png — book cover

HOW TO GET A REAL URL:
Upload these files to a static website host (for example, GitHub Pages, Netlify, or Cloudflare Pages). The host will give you a public web address. You can later connect a custom domain you own.

IMPORTANT:
Before publishing, replace the contact placeholder with the public email/social account you actually want readers and publishers to use.
